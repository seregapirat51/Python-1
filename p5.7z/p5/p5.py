# message = "Hello"
#
# for c in message:
#     print(c)
# else:
#     print(f"Последний символ: {c}. Цикл завершен")
# print("Работа программы завершена")
#
#
#
# for c1 in "ab":
#     for c2 in "ba":
#         print(f"{c1}-{c2}")
#


a = int(input())
b = int(input())
c = input()
while c!="0":
    if c=="+":
        print(a+b)
    elif c=="-":
        print(a-b)
    elif c=="*":
        print(a*b)
    elif c=="/":
        print(a/b)
    else:
        print("Нет такого действия")
    a = int(input())
    b = int(input())
    c = input()

    number = input('Введите число')
    even = 0
    odd = 0
    for f in number:
        i = int(f)
        if i % 2 == 0:
            even += 1 else:
            odd += 1
            print(f'у числа {number}: четных цифр - {even}, нечетных - {odd} ')





