number = 0
while number < 5:
     print(f"number={number}")
     number += 1
     print("Работа программы завершена")
     print(f"number={number}")


number = 1
while number < 5:
     print(f"number = {number}")
     number += 1
else:
     print(f"number = {number}. Работа цикла завершена")
print("Работа программы завершена")


number = 10
while number < 5:
     print(f"number= {number}")
     number += 1
else:
     print(f"number = {number}. Работа цикла завершена")
print("Работа программы завершена")


i = 1
j = 1
while i < 10:
     while j < 10:
          print(i * j, end="\t")
          j += 1
     print ("\n")
     j = 1
     i += 1



