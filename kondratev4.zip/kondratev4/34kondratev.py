# import math
#
# a=input(8)
# b=input(15)
# n=input(10)
# f=(math.log(x-5)+6)
# print(f)
import math

x = int(input())
y = int(input())
z = int(input())

r=(math.e**math.fabs(x-y)*math.fabs(x-y)**(x+y)/math.atan(x)+math.atan(z))+((x**6+math.log(y)**2)**1/3)
print(x,y,z,r)


