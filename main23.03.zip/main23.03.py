import math
# a = -0.9
# b = 2.7
# h = 0.3
# c = 0
# while a < b:
#     y = (a + math.sin(math.pi/4))/(1-(2*a*math.cos(math.pi/4)+(a*a)))
#     print("Порядковый номер" , c)
#     print("значение аргумента " , a)
#     print("значение функций" , у)
#     a = a + h
#     c+=1
a = -0.9
b = 2.7
h = 0.3
c = 0
while a < b:
    y = (1 - a**2/4) * math.cos(a) - (a/2) * math.sin(a)
    print('порядковый номер' , c)
    print('значение аргумента' , a)
    print('значение функции' , y)
    a = a+h
    c = c+1