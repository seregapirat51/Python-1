string = "gpsgs"
for char in string:
    print(char)

name = "g"
surname = "sdsfs"
fullname = name + " "
var = surname
print (fullname)

name = "yawer"
age = 16
info = "name: " + name + " age: "
str(age)
print(info)

numbers = [1, 2,
3, 4, 5]
spells = ["wwq"
"eew"
, "qwe" ]
numbers1 = [2]
numbers2 = [1]
print (numbers)
print (spells)

str = input ()
print(str.replace ("a", "ф*"))
count = 0
for i in range (str.__len__()):
    if str[i]== "a":
        count += 1
print (count)
