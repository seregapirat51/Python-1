

s = input()  # считываем строку
indexstart = 0
indexend = 0
count = 0
for i in range (s.__len__()):
        if s[i]==" ":
            indexstart = i
            break
for i in range (s.__len__()):
        if s[i]==" ":
            count += 1
for i in range (s.__len__()):
        if i == count:
            indexend = i
result = s[indexstart:indexend]
print(result)



