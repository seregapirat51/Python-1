import math

a = int(input("a="))
b = int(input("b="))
z1 = (math.cos(a)-math.cos(b))-(math.sin(a)-math.sin(b))
z2 = (-4*math.sin((a-b)/2)**2)*math.cos(a+b)
print(z1)
print(z2)




